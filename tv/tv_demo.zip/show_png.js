/**
 * author: LanFly
 * email: bluescode@outlook.com
 * document: http://lanfly.vicp.io/tv/doc.html
 */

var Device = require('onedevice');

var ssd1306 = new Device({
    description: 'test drawPNG',
    model: 'ssd1306',
    width: 128,
    height: 64,
    address: 0x3c,
    device: '/dev/i2c-1'
});

ssd1306.drawPNG('./starwars.png', false, function (error) {
    if (error) {
        console.log('png 图片显示错误，请确认图片的文件名是否正确');
        console.log(error);
    } else {
        console.log('显示PNG图片完成');
    }
});