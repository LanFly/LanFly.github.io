/**
 * author: LanFly
 * email: bluescode@outlook.com
 * document: http://lanfly.vicp.io/tv/doc.html
 */

var Device = require('onedevice');

var ssd1306 = new Device({
    description: 'test draw animation',
    model: 'ssd1306',
    width: 128,
    height: 64,
    address: 0x3c,
    device: '/dev/i2c-1'
});

// 记录当前水平位置
var x = 0;
// 记录扫描方向
var dt = 1;

function render(oled) {
    // 每次都先清除屏幕
    oled.clearDisplay();
    // 然后画一条垂直的直线，前2个参数表示起点的横纵坐标，接下来2个参数表示终点的横纵坐标，最后一个参数表示颜色亮
    oled.drawLine(x, 0, x, 63, 1);
    // 每次移动一个像素点
    x = x + dt;
    // 如果到达屏幕右边界，则改变方向，向左移动扫描
    if (x > 127) {
        x = 127;
        dt = -1;
    // 如果到达屏幕左边界，则改变方向，向右移动扫描
    } else if (x < 0) {
        x = 0;
        dt = 1;
    }
    // 每隔30毫秒移动一次，注意不能太快
    setTimeout(function () {
        render(oled);
    }, 30);
}

// 原生 api 挂载在 oled 对象上，开始显示
render(ssd1306.oled);