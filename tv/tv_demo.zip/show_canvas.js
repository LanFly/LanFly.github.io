/**
 * author: LanFly
 * email: bluescode@outlook.com
 * document: http://lanfly.vicp.io/tv/doc.html
 */

var Device = require('onedevice');
// 注意，这里多了一行，我们要使用 canvas
var Canvas = require('canvas');

var ssd1306 = new Device({
    description: 'test drawCanvas',
    model: 'ssd1306',
    width: 128,
    height: 64,
    address: 0x3c,
    device: '/dev/i2c-1'
});

// 创建一个 canvas 画布，并且大小是 128*64
var canvas = new Canvas(128, 64);
var ctx = canvas.getContext('2d');

// 我们先设置字体和大小，然后把画笔的颜色设置成白色，最后显示2行文字
ctx.font = '18px Impact';
ctx.fillStyle = '#FFF';
ctx.fillText("hello Canvas", 0, 20);
ctx.fillText("你好啊", 0, 50);

// 上面是 canvas 的操作，现在我们让屏幕显示 canvas 的内容
ssd1306.drawCanvas(canvas);